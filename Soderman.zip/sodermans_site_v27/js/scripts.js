// scripts.js
document.getElementById('nav-toggle').addEventListener('click', function(){
  document.querySelector('.nav-list').classList.toggle('active');
});
